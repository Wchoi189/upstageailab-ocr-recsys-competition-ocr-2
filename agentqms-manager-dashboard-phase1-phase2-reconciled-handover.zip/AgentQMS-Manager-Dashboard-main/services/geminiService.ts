// DEPRECATED: This file is kept for backward compatibility.
// Please import from 'aiService.ts' for future development.

export { auditDocumentation, generateArchitectureAdvice, generateAgentSystemPrompt } from './aiService';
